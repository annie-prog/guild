﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Guild
{
    public class Guild
    {
        private readonly List<Player> roster;
        public string Name { get; set; }
        public int Capacity { get; set; }
        public int Count => roster.Count;

        public Guild()
        {
            roster = new List<Player>();
        }

        public Guild(string name, int capacity) : this()
        {
            Name = name;
            Capacity = capacity;
        }

        public void AddPlayer(Player player)
        {
            if (roster.Count + 1 <= Capacity)
                roster.Add(player);
        }

        public bool RemovePlayer(string name)
        {
            Player player = roster.FirstOrDefault(r => r.Name == name);
            if (player != null)
            {
                roster.Remove(player);
                return true;
            }
            return false;
        }

        public void PromotePlayer(string name)
        {
            Player player = roster.FirstOrDefault(r => r.Name == name);
            if (player != null)
            {
                player.Rank = "Member";
            }
        }

        public void DemotePlayer(string name)

        {
            Player player = roster.FirstOrDefault(r => r.Name == name);
            if (player != null)
            {
                player.Rank = "Trial";
            }
        }

        public Player[] KickPlayersByClass(string clas)
        {
            Player[] kicked = roster.Where(p => p.Class == clas).ToArray();
            roster.RemoveAll(p => p.Class == clas);
            return kicked;
        }

        public string Report()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Players in the guild: {Name}");
            foreach (var player in roster)
            {
                sb.AppendLine($"{player}");
            }
            return sb.ToString().TrimEnd();
        }
    }
}
